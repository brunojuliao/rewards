---
name: Bug report
about: pregather info
title: ''
labels: ''
assignees: ''

---

**Before posting issue...**

1. Run using non-headless mode: `python BingRewards -nhl`
2. Copy relevant output from `errors.log`

**Your Issue - include the details from the above steps:**
